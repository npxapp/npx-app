import { Drawer } from './modules/Drawer.js';
import { Carousel } from './modules/Carousel.js';
import { Accordion } from './modules/Accordion.js';
import { SnackBar } from './modules/SnackBar.js';
import { Router } from './modules/Router.js';

class App {
    constructor() {
        document.addEventListener('DOMContentLoaded', () => {
            this.init();
        });
    }
    
    init() {
        if (!document.getElementById('main-content')) {
            const mainContent = document.createElement('main');
            mainContent.id = 'main-content';
            const overlay = document.querySelector('.overlay');
            const existingContent = overlay.nextElementSibling;

            overlay.parentNode.insertBefore(mainContent, existingContent);

            if (existingContent && existingContent.classList.contains('carousel')) {
                mainContent.appendChild(existingContent.cloneNode(true));
                mainContent.appendChild(document.querySelector('.card-group').cloneNode(true));
                existingContent.remove();
                document.querySelector('.card-group').remove();
            }
        }

        this.router = new Router({
            carousel: Carousel,
            accordion: Accordion
        });
        
        this.drawer = new Drawer();
        this.snackbar = new SnackBar();
    }
}

new App();