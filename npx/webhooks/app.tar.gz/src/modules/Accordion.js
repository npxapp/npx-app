export class Accordion {
    constructor() {
        this.init();
    }
    
    init() {
        document.querySelectorAll('.accordion-header').forEach(header => {
            header.addEventListener('click', () => this.toggleAccordion(header));
        });
        
        this.setupDownloadButtons();
    }
    
    toggleAccordion(header) {
        const item = header.closest('.accordion-item');
        const isActive = item.classList.contains('active');
        
        if (!isActive) {
            item.classList.add('active');
            this.updateAccordionIcon(item.querySelector('.accordion-icon'), 'remove');
        } else {
            item.classList.remove('active');
            this.updateAccordionIcon(item.querySelector('.accordion-icon'), 'add');
        }
    }

    updateAccordionIcon(iconElement, iconName) {
        iconElement.textContent = iconName;
    }
    
    setupDownloadButtons() {
        document.querySelectorAll('.download-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const package_package = e.target.closest('.card-content').querySelector('.card-header').textContent;
                alert(`Downloading ${package_package}`);
            });
        });
    }
}