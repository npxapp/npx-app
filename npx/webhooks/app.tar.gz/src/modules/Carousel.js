export class Carousel {
  constructor() {
    this.carousel = document.querySelector('.carousel-inner');
    this.prevButton = document.querySelector('.carousel-nav.left');
    this.nextButton = document.querySelector('.carousel-nav.right');
    this.startX = 0;
    this.currentSlide = 0;
    this.slideWidth = 100;
    this.totalSlides = 3;
    this.isDragging = false;
    this.init();
  }

  init() {
    this.prevButton.addEventListener('click', () => this.moveCarousel('prev'));
    this.nextButton.addEventListener('click', () => this.moveCarousel('next'));
    this.setupTouchEvents();
  }

  moveCarousel(direction) {
    if (direction === 'next' && this.currentSlide < this.totalSlides - 1) {
      this.currentSlide++;
    } else if (direction === 'prev' && this.currentSlide > 0) {
      this.currentSlide--;
    }
    this.updateCarouselPosition();
  }

  updateCarouselPosition() {
    this.carousel.style.transition = 'transform 0.3s ease-out';
    this.carousel.style.transform = `translateX(${-this.currentSlide * this.slideWidth}%)`;
  }

  setupTouchEvents() {
    this.carousel.addEventListener('touchstart', (e) => {
      this.isDragging = true;
      this.startX = e.touches[0].clientX;
      this.carousel.style.transition = 'none';
    }, { passive: true });

    this.carousel.addEventListener('touchmove', (e) => {
      if (!this.isDragging) return;
      const currentX = e.touches[0].clientX;
      const diff = this.startX - currentX;
      const threshold = 5;
      const atStart = this.currentSlide === 0 && diff < 0;
      const atEnd = this.currentSlide === this.totalSlides - 1 && diff > 0;
      if (!atStart && !atEnd && Math.abs(diff) > threshold) {
        e.preventDefault();
      }
      const newPosition = -this.currentSlide * this.slideWidth - (diff / this.carousel.offsetWidth * 100);
      const minTransform = -(this.totalSlides - 1) * this.slideWidth;
      const boundedPosition = Math.max(minTransform, Math.min(0, newPosition));
      this.carousel.style.transform = `translateX(${boundedPosition}%)`;
    }, { passive: false });

    this.carousel.addEventListener('touchend', (e) => {
      if (!this.isDragging) return;
      this.isDragging = false;
      const diff = this.startX - e.changedTouches[0].clientX;
      const moveThreshold = 50;
      if (Math.abs(diff) > moveThreshold) {
        if (diff > 0 && this.currentSlide < this.totalSlides - 1) {
          this.currentSlide++;
        } else if (diff < 0 && this.currentSlide > 0) {
          this.currentSlide--;
        }
      }
      this.updateCarouselPosition();
    }, { passive: true });

    this.carousel.addEventListener('touchcancel', () => {
      this.isDragging = false;
      this.updateCarouselPosition();
    }, { passive: true });
  }
}