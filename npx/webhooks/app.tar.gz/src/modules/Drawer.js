export class Drawer {
  constructor() {
    this.menuIcon = document.querySelector('.menu-icon');
    this.drawer = document.querySelector('.drawer');
    this.overlay = document.querySelector('.overlay');
    this.closeIcon = document.querySelector('.close-icon');

    this.init();
  }

  init() {
    this.menuIcon.addEventListener('click', () => this.toggleDrawer());
    this.closeIcon.addEventListener('click', () => this.closeDrawer());
    this.overlay.addEventListener('click', () => this.closeDrawer());
  }

  toggleDrawer() {
    this.drawer.classList.toggle('open');
    this.overlay.classList.toggle('active');
  }

  closeDrawer() {
    this.drawer.classList.remove('open');
    this.overlay.classList.remove('active');
  }
}