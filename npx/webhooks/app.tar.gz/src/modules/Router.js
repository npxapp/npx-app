import { Home } from '../pages/Home.js';
import { Demo } from '../pages/Demo.js';
import { Favorite } from '../pages/Favorite.js';
import { Notifications } from '../pages/Notifications.js';
import { Settings } from '../pages/Settings.js';
import { Profile } from '../pages/Profile.js';

export class Router {
    constructor(components) {
        this.components = components;
        this.routes = {
            '/': () => this.loadPage(Home),
            '/demo': () => this.loadPage(Demo),
            '/favorite': () => this.loadPage(Favorite),
            '/notifications': () => this.loadPage(Notifications),
            '/settings': () => this.loadPage(Settings),
            '/person': () => this.loadPage(Profile)
        };

        this.baseURL = window.location.origin + window.location.pathname.replace(/\/[^/]*$/, '');
        this.mainContent = document.querySelector('.main');
        
        if (!this.mainContent) return;

        this.setupEventListeners();
        this.updateContent();
    }

    getPath(href) {
        if (href === '#') return '/';
        else if (href === '#demo') return '/demo';
        else if (href === '#favorite') return '/favorite';
        else if (href === '#notifications') return '/notifications';
        else if (href === '#settings') return '/settings';
        else if (href === '#person') return '/person';
        return href.replace(/^#/, '');
    }

    setupEventListeners() {
        const drawerLinks = document.querySelectorAll('.drawer-links a');
        this.setupLinks(drawerLinks, true);

        const snackbarLinks = document.querySelectorAll('.snackbar a');
        this.setupLinks(snackbarLinks, false);

        window.addEventListener('popstate', () => {
            this.updateContent();
        });
    }

    setupLinks(links, isDrawerLink) {
        links.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const href = link.getAttribute('href');
                const path = this.getPath(href);
                const fullPath = `${this.baseURL}${path}`;
                history.pushState({}, '', fullPath);
                this.updateContent(path);

                if (isDrawerLink) {
                    const drawer = document.querySelector('.drawer');
                    if (drawer && drawer.classList.contains('drawer-open')) {
                        drawer.classList.remove('drawer-open');
                        document.querySelector('.overlay').classList.remove('visible');
                    }
                }
            });
        });
    }

    updateContent(path = window.location.pathname) {
        const normalizedPath = path.replace(/^\//, '');
        const routeFunction = this.routes[`/${normalizedPath}`];

        if (routeFunction) {
            routeFunction();
        } else {
            this.loadPage(Home);
        }
    }

    loadPage(PageComponent) {
        if (!this.mainContent) return;

        this.mainContent.classList.add('loading');

        try {
            const page = new PageComponent();
            this.mainContent.innerHTML = page.render();

            this.onImagesLoaded(() => {
                this.initComponents();
                this.mainContent.classList.remove('loading');
            });
        } catch (error) {
            this.mainContent.classList.remove('loading');
        }
    }

    onImagesLoaded(callback) {
        const images = this.mainContent.querySelectorAll('img');
        
        if (images.length === 0) {
            callback();
            return;
        }

        const imagePromises = Array.from(images).map(img => {
            return new Promise((resolve) => {
                if (img.complete) {
                    resolve();
                } else {
                    img.onload = resolve;
                    img.onerror = resolve;
                }
            });
        });

        Promise.all(imagePromises).then(callback).catch(callback);
    }

    initComponents() {
        if (this.mainContent.querySelector('.carousel') && this.components.carousel) {
            new this.components.carousel();
        }

        if (this.mainContent.querySelector('.accordion-container') && this.components.accordion) {
            new this.components.accordion();
        }
    }
}