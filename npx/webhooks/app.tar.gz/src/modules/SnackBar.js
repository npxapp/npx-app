export class SnackBar {
    constructor() {
        this.toggleIcon = document.querySelector('.snackbar-icon');
        this.snackbar = document.querySelector('.snackbar');
        this.isOpen = false;
        this.init();
    }

    init() {
        this.toggleIcon.addEventListener('click', () => this.toggleSnackBar());
    }

    toggleSnackBar() {
        this.isOpen = !this.isOpen;
        this.snackbar.classList.toggle('open');
        this.toggleIcon.style.transform = this.isOpen ? 'rotate(180deg)' : 'rotate(0deg)';
    }
}