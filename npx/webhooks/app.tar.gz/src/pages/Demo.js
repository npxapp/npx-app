export class Demo {
    constructor() {
        this.render();
    }

    render() {
        return `
            <div class="carousel">
                <span class="material-icons carousel-nav left">navigate_before</span>
                <span class="material-icons carousel-nav right">navigate_next</span>
                <div class="carousel-inner">
                    <div class="carousel-item">
                        <img src="images/Image.svg" alt="Cosmic Grid 1">
                        <h2 class="carousel-one">Pro Demo</h2>
                    </div>
                    <div class="carousel-item">
                        <img src="images/Image.svg" alt="Cosmic Grid 2">
                        <h2 class="carousel-two">Atomic Design</h2>
                    </div>
                    <div class="carousel-item">
                        <img src="images/Image.svg" alt="Cosmic Grid 3">
                        <h2 class="carousel-three">Experience Pro</h2>
                    </div>
                </div>
            </div>

            <div class="card-group">
                <div class="card">
                    <img src="images/Image.svg" alt="Tech 1">
                    <div class="card-content">
                        <h3 class="card-header card-first">Pro Demo</h3>
                        <button class="download-btn">Try Now</button>
                    </div>
                </div>
                <div class="card">
                    <img src="images/Image.svg" alt="Tech 2">
                    <div class="card-content">
                        <h3 class="card-header card-second">Trial</h3>
                        <button class="download-btn">Try Now</button>
                    </div>
                </div>
                <div class="card">
                    <img src="images/Image.svg" alt="Tech 3">
                    <div class="card-content">
                        <h3 class="card-header card-third">Demo</h3>
                        <button class="download-btn">Try Now</button>
                    </div>
                </div>
            </div>

            <div class="accordion-container">
                <div class="accordion-item">
                    <div class="accordion-header">
                        <span class="material-icons accordion-icon">add</span>
                        <span>Getting Started</span>
                    </div>
                    <div class="accordion-content">
                        <p>Welcome to our getting started guide!</p>
                        <div class="sub-accordion">
                            <div class="accordion-item">
                                <div class="accordion-header">
                                    <span class="material-icons accordion-icon">add</span>
                                    <span>Installation</span>
                                </div>
                                <div class="accordion-content">
                                    Installation steps go here...
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <div class="accordion-header">
                        <span class="material-icons accordion-icon">add</span>
                        <span>Features</span>
                    </div>
                    <div class="accordion-content">
                        Discover our amazing features...
                    </div>
                </div>
                <div class="accordion-item">
                    <div class="accordion-header">
                        <span class="material-icons accordion-icon">add</span>
                        <span>FAQ</span>
                    </div>
                    <div class="accordion-content">
                        Frequently asked questions...
                    </div>
                </div>
            </div>
            
            <section class="contact-section">
                <div class="contact-info">
                    <h2 class="title">Contact</h2>
                    <p class="address">432 Atomic St, Cyber City</p>
                    <p class="email">app@myapp.com</p>
                    <p class="phone">+1 800 555 0199</p>       
                </div>

                <form class="contact-form">
                    <div class="form-group">
                        <input type="text" placeholder="Name">
                    </div>
                    <div class="form-group">
                        <input type="email" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <textarea rows="5" placeholder="Message"></textarea>
                    </div>
                    <button type="submit" class="submit-btn">Send Message</button>
                </form>
            </section>
        `;
    }
}

