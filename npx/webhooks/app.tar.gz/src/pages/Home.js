export class Home {
    constructor() {
        this.render();
    }

    render() {
        return `
            <div class="App">
                <header class="App-header">
                    <div class="card-group">
                        <div class="card card--borderless card--no-image">
                            <div class="card-content">
                                <h3 class="card-header card-first">Pro Demo</h3>
                                <ul class="card-list">
                                    <p>Pro Pages Like Easy to Edit 
                                    Home.js and Demo.js page
                                    Router.js using history API
                                    Carousel.js, SnackBar.js, Accordion.js, Drawer.js</p>
                                </ul>
                                <h3 class="card-header card-first">Pro Features</h3>
                                <button class="download-btn">Buy</button>
                            </div>
                        </div>
                        <div class="card card--borderless card--no-image">
                            <div class="card-content">
                                <ul class="card-list">
                                    <p>Single Point of Entry,
                                    Express Middleware Server,
                                    Router.js for Single Page Application Routing,
                                    Path Mapping, Event Listeners Like PopState, 
                                    Handling Link Clicks, Updating Page Content,
                                    Loading Page Components, Waiting for Static
                                    Assets, Component Initialization</p>
                                </ul>
                                <h3 class="card-header card-first">Pro Demo</h3>
                            </div>
                        </div>
                    </div>
                    <img src="images/logo192.png" class="App-logo" alt="logo" />
                    <p>Single Page Application.</p>
                    <p>Inspired by React</p>
                    <a
                        class="App-link"
                        href="https://reactjs.org"
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        Learn React
                    </a>
                </header>
            </div>
        `;
    }
}