export class Settings {
    constructor() {
        this.render();
    }

    render() {
        return `
            <div class="App">
                <header class="App-header">
                    <img src="images/logo192.png" class="App-logo" alt="logo" />
                    <p>
                        Single Page Application.
                    </p>
                    <p>
                        Inspired by React
                    </p>

                    <a
                        class="App-link"
                        href="https://reactjs.org"
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        Learn React
                    </a>
                </header>
            </div>
        `;
    }
}

